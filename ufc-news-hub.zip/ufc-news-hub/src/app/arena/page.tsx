'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Header } from '@/components/ui/Header';
import { EventoCard } from '@/components/arena/EventoCard';
import { LutaCard } from '@/components/arena/LutaCard';
import { RankingTable } from '@/components/arena/RankingTable';
import { Countdown } from '@/components/calendario/Countdown';
import { EventoComLutas, RankingPrevisor, Previsao } from '@/types';
import { useFingerprint } from '@/hooks/useFingerprint';
import { useUserName } from '@/hooks/useUserName';

export default function ArenaPage() {
  const [proximoEvento, setProximoEvento] = useState<EventoComLutas | null>(null);
  const [eventos, setEventos] = useState<EventoComLutas[]>([]);
  const [ranking, setRanking] = useState<(RankingPrevisor & { posicao: number })[]>([]);
  const [userPrevisoes, setUserPrevisoes] = useState<Record<string, Previsao>>({});
  const [isLoading, setIsLoading] = useState(true);
  const fingerprint = useFingerprint();
  const { userName, setUserName, showNamePrompt, NamePromptModal } = useUserName();

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    if (fingerprint && proximoEvento) {
      fetchUserPrevisoes();
    }
  }, [fingerprint, proximoEvento]);

  async function fetchData() {
    try {
      const [proximoRes, eventosRes, rankingRes] = await Promise.all([
        fetch('/api/eventos/proximo'),
        fetch('/api/eventos?status=agendado&limit=6'),
        fetch('/api/ranking?limit=5'),
      ]);

      if (proximoRes.ok) {
        const data = await proximoRes.json();
        setProximoEvento(data);
      }

      if (eventosRes.ok) {
        const data = await eventosRes.json();
        setEventos(data.eventos || []);
      }

      if (rankingRes.ok) {
        const data = await rankingRes.json();
        setRanking(data.ranking || []);
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setIsLoading(false);
    }
  }

  async function fetchUserPrevisoes() {
    if (!proximoEvento || !fingerprint) return;

    const previsoes: Record<string, Previsao> = {};

    for (const luta of proximoEvento.lutas) {
      try {
        const res = await fetch(
          `/api/previsoes?luta_id=${luta.id}&fingerprint=${fingerprint}`
        );
        if (res.ok) {
          const data = await res.json();
          if (data.previsao) {
            previsoes[luta.id] = data.previsao;
          }
        }
      } catch (error) {
        console.error('Erro ao buscar previsao:', error);
      }
    }

    setUserPrevisoes(previsoes);
  }

  const handlePrevisaoSubmit = (previsao: Previsao) => {
    setUserPrevisoes((prev) => ({
      ...prev,
      [previsao.luta_id]: previsao,
    }));
  };

  return (
    <div className="min-h-screen bg-dark-bg">
      <Header />

      {/* Hero Section */}
      <section className="border-b border-dark-border bg-gradient-to-b from-ufc-red/10 to-transparent">
        <div className="container mx-auto px-4 py-8 md:py-12">
          <div className="text-center">
            <h1 className="font-display text-4xl uppercase text-dark-text md:text-6xl">
              Arena de <span className="text-ufc-red">Previsoes</span>
            </h1>
            <p className="mt-2 text-dark-textMuted">
              Faca suas previsoes, acumule pontos e dispute o ranking!
            </p>
          </div>

          {/* Proximo Evento Countdown */}
          {proximoEvento && (
            <div className="mt-8">
              <div className="text-center mb-4">
                <h2 className="font-display text-xl uppercase text-dark-textMuted">
                  Proximo Evento
                </h2>
                <Link
                  href={`/arena/evento/${proximoEvento.id}`}
                  className="font-display text-2xl uppercase text-ufc-red hover:text-ufc-redLight transition-colors"
                >
                  {proximoEvento.nome}
                </Link>
              </div>
              <Countdown targetDate={proximoEvento.data_evento} />
            </div>
          )}
        </div>
      </section>

      <div className="container mx-auto px-4 py-8">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Lutas do Proximo Evento */}
            {proximoEvento && (
              <section>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="font-display text-2xl uppercase text-dark-text">
                    Faca suas Previsoes
                  </h2>
                  <Link
                    href={`/arena/evento/${proximoEvento.id}`}
                    className="text-sm text-ufc-red hover:text-ufc-redLight"
                  >
                    Ver todas →
                  </Link>
                </div>

                {showNamePrompt && <NamePromptModal />}

                <div className="space-y-4">
                  {proximoEvento.lutas.slice(0, 5).map((luta) => (
                    <LutaCard
                      key={luta.id}
                      luta={luta}
                      userPrevisao={userPrevisoes[luta.id]}
                      fingerprint={fingerprint}
                      userName={userName}
                      onPrevisaoSubmit={handlePrevisaoSubmit}
                      showForm={!!userName}
                    />
                  ))}
                </div>

                {proximoEvento.lutas.length > 5 && (
                  <Link
                    href={`/arena/evento/${proximoEvento.id}`}
                    className="mt-4 block text-center rounded bg-dark-card border border-dark-border p-4 text-dark-textMuted hover:border-ufc-red/50 hover:text-dark-text transition-colors"
                  >
                    Ver mais {proximoEvento.lutas.length - 5} lutas →
                  </Link>
                )}
              </section>
            )}

            {/* Proximos Eventos */}
            <section>
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-display text-2xl uppercase text-dark-text">
                  Proximos Eventos
                </h2>
                <Link
                  href="/calendario"
                  className="text-sm text-ufc-red hover:text-ufc-redLight"
                >
                  Ver calendario →
                </Link>
              </div>

              {isLoading ? (
                <div className="grid gap-4 md:grid-cols-2">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <div
                      key={i}
                      className="h-48 animate-pulse rounded-lg bg-dark-card border border-dark-border"
                    />
                  ))}
                </div>
              ) : (
                <div className="grid gap-4 md:grid-cols-2">
                  {eventos
                    .filter((e) => e.id !== proximoEvento?.id)
                    .slice(0, 4)
                    .map((evento) => (
                      <EventoCard key={evento.id} evento={evento} />
                    ))}
                </div>
              )}
            </section>
          </div>

          {/* Sidebar */}
          <aside className="space-y-6">
            {/* Pontuacao */}
            <div className="rounded-lg border border-dark-border bg-dark-card p-4">
              <h3 className="font-display text-lg uppercase text-dark-text mb-3">
                Sistema de Pontos
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-dark-textMuted">Acertar vencedor</span>
                  <span className="font-bold text-ufc-red">+10 pts</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-dark-textMuted">Acertar metodo</span>
                  <span className="font-bold text-ufc-gold">+5 pts</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-dark-textMuted">Acertar round</span>
                  <span className="font-bold text-green-400">+10 pts</span>
                </div>
                <div className="border-t border-dark-border pt-2 mt-2 flex justify-between">
                  <span className="text-dark-text font-medium">
                    Maximo por luta
                  </span>
                  <span className="font-bold text-dark-text">25 pts</span>
                </div>
              </div>
            </div>

            {/* Top Previsores */}
            <div className="rounded-lg border border-dark-border bg-dark-card p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-display text-lg uppercase text-dark-text">
                  Top Previsores
                </h3>
                <Link
                  href="/arena/ranking"
                  className="text-xs text-ufc-red hover:text-ufc-redLight"
                >
                  Ver todos →
                </Link>
              </div>

              {isLoading ? (
                <div className="space-y-2">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div
                      key={i}
                      className="h-16 animate-pulse rounded-lg bg-dark-border"
                    />
                  ))}
                </div>
              ) : (
                <RankingTable
                  ranking={ranking}
                  currentUserFingerprint={fingerprint}
                  compact
                />
              )}
            </div>

            {/* User Stats */}
            {userName && (
              <div className="rounded-lg border border-ufc-red/50 bg-ufc-red/5 p-4">
                <h3 className="font-display text-lg uppercase text-dark-text mb-2">
                  Ola, {userName}!
                </h3>
                <p className="text-sm text-dark-textMuted">
                  Suas previsoes sao salvas automaticamente. Continue fazendo
                  previsoes para subir no ranking!
                </p>
                <button
                  onClick={() => setUserName('')}
                  className="mt-2 text-xs text-dark-textMuted hover:text-ufc-red"
                >
                  Trocar nome
                </button>
              </div>
            )}
          </aside>
        </div>
      </div>
    </div>
  );
}
