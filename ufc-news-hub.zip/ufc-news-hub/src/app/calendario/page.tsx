'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Header } from '@/components/ui/Header';
import { CalendarioGrid } from '@/components/calendario/CalendarioGrid';
import { Countdown } from '@/components/calendario/Countdown';
import { Evento, EventoComLutas } from '@/types';

type FilterStatus = 'todos' | 'agendado' | 'finalizado';

export default function CalendarioPage() {
  const [eventos, setEventos] = useState<Evento[]>([]);
  const [proximoEvento, setProximoEvento] = useState<EventoComLutas | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState<FilterStatus>('todos');

  useEffect(() => {
    fetchData();
  }, [filter]);

  async function fetchData() {
    setIsLoading(true);
    try {
      const statusParam = filter !== 'todos' ? `?status=${filter}` : '';
      const [eventosRes, proximoRes] = await Promise.all([
        fetch(`/api/eventos${statusParam}&limit=50`),
        fetch('/api/eventos/proximo'),
      ]);

      if (eventosRes.ok) {
        const data = await eventosRes.json();
        setEventos(data.eventos || []);
      }

      if (proximoRes.ok) {
        const data = await proximoRes.json();
        setProximoEvento(data);
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setIsLoading(false);
    }
  }

  const filterOptions: { value: FilterStatus; label: string }[] = [
    { value: 'todos', label: 'Todos' },
    { value: 'agendado', label: 'Proximos' },
    { value: 'finalizado', label: 'Finalizados' },
  ];

  return (
    <div className="min-h-screen bg-dark-bg">
      <Header />

      {/* Hero com proximo evento */}
      {proximoEvento && (
        <section className="border-b border-dark-border bg-gradient-to-b from-ufc-red/10 to-transparent">
          <div className="container mx-auto px-4 py-8">
            <div className="text-center mb-6">
              <h2 className="font-display text-sm uppercase text-dark-textMuted tracking-widest">
                Proximo Evento
              </h2>
              <Link
                href={`/arena/evento/${proximoEvento.id}`}
                className="block mt-2"
              >
                <h1 className="font-display text-3xl uppercase text-dark-text hover:text-ufc-red transition-colors md:text-5xl">
                  {proximoEvento.nome}
                </h1>
              </Link>
              <p className="mt-2 text-dark-textMuted">
                {new Date(proximoEvento.data_evento).toLocaleDateString('pt-BR', {
                  weekday: 'long',
                  day: 'numeric',
                  month: 'long',
                })}
                {proximoEvento.local_evento && ` - ${proximoEvento.local_evento}`}
              </p>
            </div>

            <Countdown targetDate={proximoEvento.data_evento} />

            <div className="mt-6 flex justify-center gap-4">
              <Link
                href={`/arena/evento/${proximoEvento.id}`}
                className="rounded bg-ufc-red px-6 py-3 font-bold text-white transition-colors hover:bg-ufc-redLight"
              >
                Fazer Previsoes
              </Link>
              <Link
                href={`/calendario/evento/${proximoEvento.id}`}
                className="rounded border border-dark-border px-6 py-3 font-medium text-dark-text transition-colors hover:bg-dark-card"
              >
                Ver Detalhes
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="font-display text-2xl uppercase text-dark-text md:text-3xl">
              Calendario UFC
            </h1>
            <p className="mt-1 text-dark-textMuted">
              Todos os eventos e lutas do UFC
            </p>
          </div>

          {/* Filter */}
          <div className="flex gap-2">
            {filterOptions.map((opt) => (
              <button
                key={opt.value}
                onClick={() => setFilter(opt.value)}
                className={`rounded px-4 py-2 text-sm font-medium transition-colors ${
                  filter === opt.value
                    ? 'bg-ufc-red text-white'
                    : 'bg-dark-card text-dark-textMuted hover:text-dark-text'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Grid */}
        <CalendarioGrid eventos={eventos} isLoading={isLoading} />
      </div>
    </div>
  );
}
