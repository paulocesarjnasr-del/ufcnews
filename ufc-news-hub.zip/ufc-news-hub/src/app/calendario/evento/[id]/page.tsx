'use client';

import { useState, useEffect, use } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Header } from '@/components/ui/Header';
import { Countdown } from '@/components/calendario/Countdown';
import { OndeAssistir } from '@/components/calendario/OndeAssistir';
import { EventoComLutas, LutaComLutadores } from '@/types';

interface PageProps {
  params: Promise<{ id: string }>;
}

export default function EventoCalendarioPage({ params }: PageProps) {
  const { id } = use(params);
  const [evento, setEvento] = useState<EventoComLutas | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchEvento();
  }, [id]);

  async function fetchEvento() {
    try {
      const res = await fetch(`/api/eventos/${id}`);
      if (res.ok) {
        const data = await res.json();
        setEvento(data);
      }
    } catch (error) {
      console.error('Erro ao carregar evento:', error);
    } finally {
      setIsLoading(false);
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-dark-bg">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 w-48 bg-dark-card rounded" />
            <div className="h-48 bg-dark-card rounded" />
          </div>
        </div>
      </div>
    );
  }

  if (!evento) {
    return (
      <div className="min-h-screen bg-dark-bg">
        <Header />
        <div className="container mx-auto px-4 py-8 text-center">
          <h1 className="font-display text-2xl text-dark-text">
            Evento nao encontrado
          </h1>
          <Link
            href="/calendario"
            className="mt-4 inline-block text-ufc-red hover:text-ufc-redLight"
          >
            ← Voltar para Calendario
          </Link>
        </div>
      </div>
    );
  }

  const dataEvento = new Date(evento.data_evento);
  const isPast = dataEvento < new Date();

  // Agrupar lutas
  const lutasPorTipo = {
    main: evento.lutas.filter(
      (l) => l.tipo === 'main_event' || l.tipo === 'co_main'
    ),
    principal: evento.lutas.filter((l) => l.tipo === 'card_principal'),
    preliminar: evento.lutas.filter(
      (l) => l.tipo === 'preliminar' || l.tipo === 'early_prelim'
    ),
  };

  return (
    <div className="min-h-screen bg-dark-bg">
      <Header />

      {/* Hero */}
      <section className="border-b border-dark-border bg-gradient-to-b from-ufc-red/10 to-transparent">
        <div className="container mx-auto px-4 py-8">
          {/* Breadcrumb */}
          <div className="mb-4 flex items-center gap-2 text-sm text-dark-textMuted">
            <Link href="/calendario" className="hover:text-ufc-red">
              Calendario
            </Link>
            <span>/</span>
            <span className="text-dark-text">{evento.nome}</span>
          </div>

          <div className="grid gap-8 md:grid-cols-2 items-center">
            <div>
              {/* Badge */}
              <div className="flex items-center gap-2 mb-2">
                <span
                  className={`rounded px-2 py-1 text-xs font-bold uppercase ${
                    evento.tipo === 'PPV'
                      ? 'bg-ufc-red text-white'
                      : 'bg-dark-border text-dark-textMuted'
                  }`}
                >
                  {evento.tipo}
                </span>
                {evento.status === 'finalizado' && (
                  <span className="rounded bg-dark-border px-2 py-1 text-xs font-bold uppercase text-dark-textMuted">
                    FINALIZADO
                  </span>
                )}
              </div>

              <h1 className="font-display text-3xl uppercase text-dark-text md:text-4xl">
                {evento.nome}
              </h1>

              <div className="mt-4 space-y-2 text-dark-textMuted">
                <p className="flex items-center gap-2">
                  <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  {dataEvento.toLocaleDateString('pt-BR', {
                    weekday: 'long',
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                  })}
                </p>
                <p className="flex items-center gap-2">
                  <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  {dataEvento.toLocaleTimeString('pt-BR', {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}{' '}
                  (horario de Brasilia)
                </p>
                {evento.local_evento && (
                  <p className="flex items-center gap-2">
                    <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    {evento.local_evento}
                    {evento.cidade && `, ${evento.cidade}`}
                    {evento.pais && ` - ${evento.pais}`}
                  </p>
                )}
              </div>

              <div className="mt-6">
                <OndeAssistir ondeAssistir={evento.onde_assistir} tipo={evento.tipo} />
              </div>

              {!isPast && (
                <Link
                  href={`/arena/evento/${evento.id}`}
                  className="mt-6 inline-block rounded bg-ufc-red px-6 py-3 font-bold text-white transition-colors hover:bg-ufc-redLight"
                >
                  Fazer Previsoes
                </Link>
              )}
            </div>

            {/* Countdown */}
            {!isPast && evento.status === 'agendado' && (
              <div className="flex justify-center">
                <div className="rounded-lg border border-dark-border bg-dark-card p-6">
                  <Countdown targetDate={evento.data_evento} />
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Card de Lutas */}
      <div className="container mx-auto px-4 py-8">
        {/* Main Card */}
        {lutasPorTipo.main.length > 0 && (
          <section className="mb-8">
            <h2 className="mb-4 font-display text-xl uppercase text-ufc-red">
              Main Card
            </h2>
            <div className="space-y-3">
              {lutasPorTipo.main.map((luta) => (
                <LutaItem key={luta.id} luta={luta} />
              ))}
            </div>
          </section>
        )}

        {/* Card Principal */}
        {lutasPorTipo.principal.length > 0 && (
          <section className="mb-8">
            <h2 className="mb-4 font-display text-xl uppercase text-dark-text">
              Card Principal
            </h2>
            <div className="space-y-3">
              {lutasPorTipo.principal.map((luta) => (
                <LutaItem key={luta.id} luta={luta} />
              ))}
            </div>
          </section>
        )}

        {/* Preliminares */}
        {lutasPorTipo.preliminar.length > 0 && (
          <section>
            <h2 className="mb-4 font-display text-xl uppercase text-dark-textMuted">
              Preliminares
            </h2>
            <div className="space-y-3">
              {lutasPorTipo.preliminar.map((luta) => (
                <LutaItem key={luta.id} luta={luta} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

function LutaItem({ luta }: { luta: LutaComLutadores }) {
  const isFinished = luta.status === 'finalizada';

  return (
    <div className="rounded-lg border border-dark-border bg-dark-card p-4 transition-colors hover:bg-dark-cardHover">
      <div className="flex items-center justify-between gap-4">
        {/* Lutador 1 */}
        <div className="flex flex-1 items-center gap-3">
          <div className={`relative h-12 w-12 overflow-hidden rounded-full border-2 ${
            isFinished && luta.vencedor_id === luta.lutador1.id
              ? 'border-green-500'
              : isFinished && luta.vencedor_id
              ? 'border-dark-border opacity-60'
              : 'border-dark-border'
          }`}>
            {luta.lutador1.imagem_url ? (
              <Image
                src={luta.lutador1.imagem_url}
                alt={luta.lutador1.nome}
                fill
                className="object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-dark-border text-lg font-bold text-dark-textMuted">
                {luta.lutador1.nome.charAt(0)}
              </div>
            )}
          </div>
          <div>
            <Link
              href={`/lutadores/${luta.lutador1.id}`}
              className="font-display text-lg uppercase text-dark-text hover:text-ufc-red"
            >
              {luta.lutador1.nome}
            </Link>
            <p className="text-xs text-dark-textMuted">
              {(luta.lutador1 as any).vitorias || 0}-{(luta.lutador1 as any).derrotas || 0}
            </p>
          </div>
        </div>

        {/* VS / Resultado */}
        <div className="flex flex-col items-center px-4">
          {isFinished && luta.metodo ? (
            <div className="text-center">
              <span className="text-xs font-bold text-ufc-red">{luta.metodo}</span>
              {luta.round_final && (
                <p className="text-xs text-dark-textMuted">
                  R{luta.round_final} {luta.tempo_final}
                </p>
              )}
            </div>
          ) : (
            <span className="font-display text-lg text-dark-textMuted">VS</span>
          )}
          <span className="mt-1 text-xs text-dark-textMuted">{luta.categoria_peso}</span>
          {luta.is_titulo && (
            <span className="mt-1 rounded bg-ufc-gold px-2 py-0.5 text-xs font-bold text-dark-bg">
              TITULO
            </span>
          )}
        </div>

        {/* Lutador 2 */}
        <div className="flex flex-1 items-center gap-3 justify-end">
          <div className="text-right">
            <Link
              href={`/lutadores/${luta.lutador2.id}`}
              className="font-display text-lg uppercase text-dark-text hover:text-ufc-red"
            >
              {luta.lutador2.nome}
            </Link>
            <p className="text-xs text-dark-textMuted">
              {(luta.lutador2 as any).vitorias || 0}-{(luta.lutador2 as any).derrotas || 0}
            </p>
          </div>
          <div className={`relative h-12 w-12 overflow-hidden rounded-full border-2 ${
            isFinished && luta.vencedor_id === luta.lutador2.id
              ? 'border-green-500'
              : isFinished && luta.vencedor_id
              ? 'border-dark-border opacity-60'
              : 'border-dark-border'
          }`}>
            {luta.lutador2.imagem_url ? (
              <Image
                src={luta.lutador2.imagem_url}
                alt={luta.lutador2.nome}
                fill
                className="object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-dark-border text-lg font-bold text-dark-textMuted">
                {luta.lutador2.nome.charAt(0)}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
