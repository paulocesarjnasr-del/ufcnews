import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { RankingPrevisor } from '@/types';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');
    const orderBy = searchParams.get('orderBy') || 'pontos_total';
    const minPrevisoes = parseInt(searchParams.get('minPrevisoes') || '0');

    const validOrderFields = ['pontos_total', 'taxa_acerto', 'total_previsoes', 'melhor_sequencia'];
    const order = validOrderFields.includes(orderBy) ? orderBy : 'pontos_total';

    const ranking = await query<RankingPrevisor & { posicao: number }>(
      `SELECT
        *,
        RANK() OVER (ORDER BY ${order} DESC)::integer as posicao
      FROM ranking_previsores
      WHERE total_previsoes >= $1
      ORDER BY ${order} DESC
      LIMIT $2 OFFSET $3`,
      [minPrevisoes, limit, offset]
    );

    const totalResult = await query<{ count: string }>(
      `SELECT COUNT(*) as count FROM ranking_previsores WHERE total_previsoes >= $1`,
      [minPrevisoes]
    );

    // Estatísticas gerais
    const stats = await query<{
      total_previsores: number;
      total_previsoes: number;
      media_taxa_acerto: number;
    }>(
      `SELECT
        COUNT(*)::integer as total_previsores,
        SUM(total_previsoes)::integer as total_previsoes,
        ROUND(AVG(taxa_acerto), 2)::float as media_taxa_acerto
      FROM ranking_previsores
      WHERE total_previsoes >= $1`,
      [minPrevisoes]
    );

    return NextResponse.json({
      ranking,
      total: parseInt(totalResult[0]?.count || '0'),
      limit,
      offset,
      stats: stats[0] || {
        total_previsores: 0,
        total_previsoes: 0,
        media_taxa_acerto: 0,
      },
    });
  } catch (error) {
    console.error('Erro ao buscar ranking:', error);
    return NextResponse.json(
      { error: 'Erro ao buscar ranking' },
      { status: 500 }
    );
  }
}
