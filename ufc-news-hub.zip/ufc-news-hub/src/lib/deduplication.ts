import crypto from 'crypto';
import { Pool } from 'pg';
import { DeduplicationResult } from '@/types';

function normalizeTitle(title: string): string {
  return title
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Remove acentos
    .replace(/[^a-z0-9\s]/g, '') // Remove pontuação
    .replace(/\s+/g, ' ') // Normaliza espaços
    .trim();
}

export function generateHash(title: string): string {
  const normalized = normalizeTitle(title);
  return crypto.createHash('sha256').update(normalized).digest('hex');
}

export async function checkDuplicate(
  titulo: string,
  lutadoresMencionados: string[],
  pool: Pool
): Promise<DeduplicationResult> {
  const hash = generateHash(titulo);

  // 1. Verificar hash exato
  const hashCheck = await pool.query(
    'SELECT id FROM noticias WHERE hash_deduplicacao = $1',
    [hash]
  );

  if (hashCheck.rows.length > 0) {
    return { isDuplicate: true, reason: 'hash_exato', hash };
  }

  // 2. Verificar URL exata (proteção adicional)
  // Isso é feito pelo constraint UNIQUE na coluna fonte_url

  // 3. Verificar mesmo evento (mesmos lutadores nas últimas 48h)
  // Apenas se houver pelo menos 2 lutadores mencionados
  if (lutadoresMencionados.length >= 2) {
    const recentCheck = await pool.query(
      `
      SELECT DISTINCT n.id, n.titulo
      FROM noticias n
      JOIN noticia_entidades ne ON n.id = ne.noticia_id
      JOIN lutadores l ON ne.lutador_id = l.id
      WHERE LOWER(l.nome) = ANY($1::text[])
      AND n.created_at > NOW() - INTERVAL '48 hours'
      GROUP BY n.id
      HAVING COUNT(DISTINCT l.id) >= 2
    `,
      [lutadoresMencionados.map((n) => n.toLowerCase())]
    );

    // Se encontrou notícia recente com os mesmos lutadores principais,
    // pode ser uma atualização sobre o mesmo evento
    // Por segurança, não rejeitamos automaticamente, apenas logamos
    if (recentCheck.rows.length > 0) {
      console.log(
        `Possível notícia relacionada encontrada: ${recentCheck.rows[0].titulo}`
      );
      // Não retornamos como duplicata para permitir atualizações de eventos
    }
  }

  return { isDuplicate: false, hash };
}

// Verificação simplificada apenas por URL
export async function checkDuplicateByUrl(
  url: string,
  pool: Pool
): Promise<boolean> {
  const result = await pool.query(
    'SELECT id FROM noticias WHERE fonte_url = $1',
    [url]
  );
  return result.rows.length > 0;
}

// Limpar notícias antigas (mais de 30 dias)
export async function cleanOldNews(pool: Pool): Promise<number> {
  const result = await pool.query(`
    DELETE FROM noticias
    WHERE created_at < NOW() - INTERVAL '30 days'
    RETURNING id
  `);

  return result.rowCount || 0;
}
