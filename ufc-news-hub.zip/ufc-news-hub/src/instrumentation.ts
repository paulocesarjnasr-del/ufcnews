/**
 * Next.js Instrumentation - Auto-sync integrado
 *
 * Usa HTTP para chamar a API de sync, evitando problemas de bundling.
 */

const INTERVAL_MINUTES = parseInt(process.env.SYNC_INTERVAL_MINUTES || '5', 10);
const INTERVAL_MS = INTERVAL_MINUTES * 60 * 1000;

function formatTime(date: Date): string {
  return date.toLocaleTimeString('pt-BR', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
}

async function runSync(): Promise<void> {
  const now = new Date();
  console.log(`\n${'═'.repeat(50)}`);
  console.log(`🔄 [${formatTime(now)}] Auto-sync iniciando...`);
  console.log('═'.repeat(50));

  const port = process.env.PORT || '3000';
  const url = `http://localhost:${port}/api/sync`;

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const result = await response.json();

    if (result.success) {
      console.log(`✅ Sync: +${result.adicionadas} novas | ${result.duplicadas} dup | ${result.rejeitadas} rej`);
      if (result.adicionadas > 0) {
        console.log(`🎉 ${result.adicionadas} notícia(s) nova(s)!`);
      }
    } else {
      console.log(`⚠️ Sync erro: ${result.error || 'Erro desconhecido'}`);
    }
  } catch (error) {
    console.error('❌ Erro no auto-sync:', error instanceof Error ? error.message : error);
  }

  const nextSync = new Date(Date.now() + INTERVAL_MS);
  console.log(`⏳ Próximo sync: ${formatTime(nextSync)}`);
  console.log('─'.repeat(50));
}

export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    const port = process.env.PORT || '3000';
    console.log('\n╔════════════════════════════════════════════════╗');
    console.log('║     🔄 AUTO-SYNC ATIVADO                       ║');
    console.log(`║     ⏱️  Intervalo: ${INTERVAL_MINUTES} minutos | Porta: ${port}             ║`);
    console.log('╚════════════════════════════════════════════════╝\n');

    // Primeiro sync após 8 segundos (tempo do servidor iniciar)
    setTimeout(async () => {
      await runSync();
      setInterval(runSync, INTERVAL_MS);
    }, 8000);
  }
}
